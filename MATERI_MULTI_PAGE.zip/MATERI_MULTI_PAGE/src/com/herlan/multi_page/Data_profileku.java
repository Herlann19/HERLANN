package com.herlan.multi_page;

public class Data_profileku {
public static String nama ="Herlan Ardiansyah";
public static int jumlah_aplikasi = 50;
public static int jumlah_followers = 10;
public static int jumlah_following = 100;
public static String keterangan = "Bermimpilah Dan Tidurlah";


public static String username="budi";
public static String password="12345";

}
