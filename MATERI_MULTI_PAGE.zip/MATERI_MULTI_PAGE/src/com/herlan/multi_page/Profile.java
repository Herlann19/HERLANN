package com.herlan.multi_page;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends Activity {

	void tampilkandata() {
		TextView lblnama = (TextView) findViewById(R.id.namaku);
		lblnama.setText(Data_profileku.nama);

		TextView lbljmlapp = (TextView) findViewById(R.id.jmlapp);
		lbljmlapp.setText(String.valueOf(Data_profileku.jumlah_aplikasi));

		TextView lbljmlfoll = (TextView) findViewById(R.id.jmlfoll);
		lbljmlfoll.setText(String.valueOf(Data_profileku.jumlah_following));

		TextView lbljmlfoww = (TextView) findViewById(R.id.jmlfoww);
		lbljmlfoww.setText(String.valueOf(Data_profileku.jumlah_followers));

		TextView aboutnama = (TextView) findViewById(R.id.aboutNama);
		aboutnama.setText("About" + Data_profileku.nama);

		TextView lblketerangan = (TextView) findViewById(R.id.keterangan);
		lblketerangan.setText(Data_profileku.keterangan);

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		tampilkandata();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);
		
		tampilkandata();

		ImageView btnprofile = (ImageView) findViewById(R.id.btnpaneh);
		btnprofile.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(), Utama.class);
				startActivity(i);
				finish();
			}
		});
		Button btnlogout = (Button) findViewById(R.id.btnlogout);
		btnlogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(getApplicationContext(), Login.class);
				startActivity(i);
				finish();

			}
		});
		ImageView btnedit = (ImageView) findViewById(R.id.btnedit);
		btnedit.setOnClickListener(new OnClickListener() {

			public void onClick(View arg0) {
				Intent i = new Intent(getApplicationContext(), Edit_page.class);
				startActivity(i);
				finish();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.profile, menu);
		return true;
	}

}